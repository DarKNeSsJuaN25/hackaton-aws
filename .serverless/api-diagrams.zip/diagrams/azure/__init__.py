"""
Azure provides a set of services for Microsoft Azure provider.
"""

from diagrams import Node


class _Azure(Node):
    _provider = "azure"
    _icon_dir = "resources/azure"

    fontcolor = "#ffffff"


class Azure(_Azure):
    _icon = "azure.png"
